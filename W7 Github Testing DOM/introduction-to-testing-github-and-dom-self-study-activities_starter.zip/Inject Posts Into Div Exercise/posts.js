var posts = [{
    title: "MIT",
    content: "great place to hang out"
  },
  {
    title: "cricket",
    content: "takes a long time to master"
  },
  {
    title: "marmalade",
    content: "chunky is the best"
  },
  {
    title: "Good Article",
    content: "Death of Planning"
  },
  {
    title: "Cooking",
    content: 'scrambled eggs on toast'
  }
]